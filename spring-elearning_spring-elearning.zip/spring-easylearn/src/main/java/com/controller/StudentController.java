package com.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.dao.StudentDao;
import com.exception.InvalidException;
import com.model.Student;

@CrossOrigin("*")
@RestController
public class StudentController {
	
	@Autowired
	StudentDao stdDao;
	
	@RequestMapping("displayEmp")
	public Student displayEmp(){
		Student student = new Student();
		student.setStdId(1001);
		student.setStdName("SACHIN");
		student.setGender("M");
		student.setEmailId("SACHIN@GMAIL.COM");
		student.setPassword("PASSWORD");
		return student;
	}
	
	@GetMapping("displayAllStd")
	public List<Student> displayAllStd(){
		return stdDao.getAllStudents();
	}
	
	@PostMapping("registerStd")
	public String registerStd(@RequestBody Student student){
		stdDao.register(student);
		return "Registration Successful";
	}
	
	
	@RequestMapping(value="/login",method= {RequestMethod.GET,RequestMethod.POST})
	public Student authenticateStudent(@RequestBody Student student)throws Exception {
		String emailId = student.getEmailId();
		String password = student.getPassword();
		Student studentObj = null;
		if(emailId != null && password !=null) {
			studentObj = stdDao.fetchStudentByemailIdAndPassword(emailId,password);
		}
		if(studentObj == null) {
			throw new InvalidException("Bad Credentials");
			
		}
		return studentObj;
		
	}

}
