package com.dao;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.model.Student;
@Service
public class StudentDao {
	@Autowired
	StudentRepository stdRepo;
	
	public List<Student> getAllStudents(){
		return stdRepo.findAll();
	}
	public void register(Student student) {
		stdRepo.save(student);
	}
	public Student fetchStudentByemailIdAndPassword(String emailId, String password) {
		
		return stdRepo.findByEmailIdAndPassword(emailId, password);
	}

}
