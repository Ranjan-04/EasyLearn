package com.model;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class Student {
	
	

		@Id
		@GeneratedValue(strategy=GenerationType.AUTO)
		private int stdId;
		@Column(length=50)
		private String stdName;
		
		private String gender;
		java.util.Date dob;
		private String country;
		@Column(length=50)
		private String emailId;
		@Column(length=50)
		private String password;
		@Column(length=50)
		private String mobileNo;
		
		
		
		public Student() {}
		public Student(int stdId, String stdName, String gender, Date dob, String country, String emailId,
				String password,String mobileNo) {
			super();
			this.stdId = stdId;
			this.stdName = stdName;
			this.gender = gender;
			this.dob = dob;
			this.country = country;
			this.emailId = emailId;
			this.password = password;
			this.mobileNo = mobileNo;
		}
		public int getStdId() {
			return stdId;
		}
		public void setStdId(int stdId) {
			this.stdId = stdId;
		}
		public String getStdName() {
			return stdName;
		}
		public void setStdName(String stdName) {
			this.stdName = stdName;
		}
		public String getGender() {
			return gender;
		}
		public void setGender(String gender) {
			this.gender = gender;
		}
		public java.util.Date getDob() {
			return dob;
		}
		public String getCountry() {
			return country;
		}
		public void setCountry(String country) {
			this.country = country;
		}
		public String getEmailId() {
			return emailId;
		}
		public void setEmailId(String emailId) {
			this.emailId = emailId;
		}
		public String getPassword() {
			return password;
		}
		public void setPassword(String password) {
			this.password = password;
		}
		
		public String getMobileNo() {
			return mobileNo;
		}
		public void setMobileNo(String mobileNo) {
			this.mobileNo = mobileNo;
		}
		@Override
		public String toString() {
			return "Student [stdId=" + stdId + ", stdName=" + stdName + ", gender=" + gender + ", dob=" + dob
					+ ", country=" + country + ", emailId=" + emailId + ", password=" + password + ", mobileNo="
					+ mobileNo + "]";
		}
		
		
		
		
		

}
