package com.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
public class Trainer {
	
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private String trnId;
	private String trnName;
	private String trnGender;
//	private Address address;
	private String experience;
	private String qualification;
	
	public Trainer() {}
	public Trainer(String trnId, String trnName, String trnGender, String experience, String qualification) {
		super();
		this.trnId = trnId;
		this.trnName = trnName;
		this.trnGender = trnGender;
		this.experience = experience;
		this.qualification = qualification;
	}
	public String getTrnId() {
		return trnId;
	}
	public void setTrnId(String trnId) {
		this.trnId = trnId;
	}
	public String getTrnName() {
		return trnName;
	}
	public void setTrnName(String trnName) {
		this.trnName = trnName;
	}
	public String getTrnGender() {
		return trnGender;
	}
	public void setTrnGender(String trnGender) {
		this.trnGender = trnGender;
	}
	public String getExperience() {
		return experience;
	}
	public void setExperience(String experience) {
		this.experience = experience;
	}
	public String getQualification() {
		return qualification;
	}
	public void setQualification(String qualification) {
		this.qualification = qualification;
	}
	@Override
	public String toString() {
		return "Trainer [trnId=" + trnId + ", trnName=" + trnName + ", trnGender=" + trnGender + ", experience="
				+ experience + ", qualification=" + qualification + "]";
	}
	
	
	
	
	
	

}
